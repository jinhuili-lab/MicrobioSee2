testit::test_pkg('xfun', 'test-cran')
